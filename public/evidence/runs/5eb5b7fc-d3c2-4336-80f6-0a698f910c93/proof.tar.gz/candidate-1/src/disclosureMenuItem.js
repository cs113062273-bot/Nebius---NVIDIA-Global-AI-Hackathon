/* global DisclosureMenu, DisclosureMenuToggle */

import BaseMenuItem from "./_baseMenuItem.js";

/**
 * A basic navigation link contained inside of a DisclosureMenu.
 *
 * @extends BaseMenuItem
 */
class DisclosureMenuItem extends BaseMenuItem {
  /**
   * Constructs a new `DisclosureMenuItem`.
   *
   * @param {object}                options                         - The options for generating the menu item.
   * @param {HTMLElement}           options.menuItemElement         - The menu item in the DOM.
   * @param {HTMLElement}           options.menuLinkElement         - The menu item's link in the DOM.
   * @param {DisclosureMenu}        options.parentMenu              - The parent menu.
   * @param {boolean}               [options.isSubmenuItem = false] - A flag to mark if the menu item is controlling a submenu.
   * @param {?DisclosureMenu}       [options.childMenu = null]      - The child menu.
   * @param {?DisclosureMenuToggle} [options.toggle = null]         - The controller for the child menu.
   * @param {boolean}               [options.initialize = true]     - A flag to initialize the menu item immediately upon creation.
   */
  constructor({
    menuItemElement,
    menuLinkElement,
    parentMenu,
    isSubmenuItem = false,
    childMenu = null,
    toggle = null,
    initialize = true,
  }) {
    super({
      menuItemElement,
      menuLinkElement,
      parentMenu,
      isSubmenuItem,
      childMenu,
      toggle,
    });

    if (initialize) {
      this.initialize();
    }
  }
}

export default DisclosureMenuItem;
