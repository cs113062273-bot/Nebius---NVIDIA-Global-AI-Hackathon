import '../../vendor/polyfills/Function/prototype/bind'
import '../../vendor/polyfills/Event' // addEventListener and event.target normaliziation
import '../../vendor/polyfills/Element/prototype/classList'
import { nodeListForEach } from '../../common'

function Radios ($module) {
  this.$module = $module
  this.$inputs = $module.querySelectorAll('input[type="radio"]')
}

Radios.prototype.init = function () {
  var $module = this.$module
  var $inputs = this.$inputs

  /**
  * Loop over all items with [data-controls]
  * Check if they have a matching conditional reveal
  * If they do, assign attributes.
  **/
  nodeListForEach($inputs, function ($input) {
    var controls = $input.getAttribute('data-aria-controls')

    // Check if input controls anything
    // Check if content exists, before setting attributes.
    if (!controls || !$module.querySelector('#' + controls)) {
      return
    }

    // If we have content that is controlled, set attributes.
    $input.setAttribute('aria-controls', controls)
    $input.removeAttribute('data-aria-controls')
    this.setAttributes($input)
  }.bind(this))

  // Handle events
  $module.addEventListener('click', this.updateConditionals.bind(this))

  // If any radio in this module has aria-controls, listen for changes on all radios with the same name
  var hasConditional = false
  var name = null
  nodeListForEach($inputs, function ($input) {
    if ($input.getAttribute('aria-controls')) {
      hasConditional = true
      if (!name) {
        name = $input.getAttribute('name')
      }
    }
  }.bind(this))

  if (hasConditional && name) {
    var allRadios = document.querySelectorAll('input[type="radio"][name="' + name + '"]')
    nodeListForEach(allRadios, function ($radio) {
      // Avoid adding multiple listeners
      if (!$radio._govukRadiosChangeListener) {
        $radio._govukRadiosChangeListener = true
        $radio.addEventListener('change', this.updateConditionals.bind(this))
      }
    }.bind(this))
  }
}

Radios.prototype.setAttributes = function ($input) {
  var inputIsChecked = $input.checked
  $input.setAttribute('aria-expanded', inputIsChecked)

  var $content = this.$module.querySelector('#' + $input.getAttribute('aria-controls'))
  if ($content) {
    $content.classList.toggle('govuk-radios__conditional--hidden', !inputIsChecked)
  }
}

Radios.prototype.updateConditionals = function () {
  nodeListForEach(this.$inputs, function ($input) {
    // If a radio with aria-controls, handle click
    var isRadio = $input.getAttribute('type') === 'radio'
    var hasAriaControls = $input.getAttribute('aria-controls')
    if (isRadio && hasAriaControls) {
      this.setAttributes($input)
    }
  }.bind(this))
}

export default Radios
